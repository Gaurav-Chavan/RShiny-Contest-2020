#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#--------Script to install missing  Libraries------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

rm(list=ls())



#Downloading and loading required packages

req_packages <- c("shiny","shinythemes", "tidyverse", "DT","RColorBrewer","colourpicker",
                  "shinydashboardPlus","shinydashboard","dashboardthemes",
                  "ggplot2", "shinyalert","gtools","rhandsontable","shinyjqui",
                  "shinyjs","shinyWidgets",
                  "shinycssloaders","htmltools",
                  "plotly","waiter"
)

Packages_TBD <- req_packages[!(req_packages %in% installed.packages()[,"Package"])]
if(length(Packages_TBD)) install.packages(Packages_TBD)



#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#---------Import Libraries------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


##Library:-------------------------------------------------------------------------------------------
library(shiny)           #Shiny: used for base shiny app

library(shinythemes)     #Shiny: used for shiny themes

library(shinyWidgets)    #Shiny: used for shiny widgets

library(DT)              #Data & Table: used for datatables

library(RColorBrewer)    #Colours: used for colour palettes

library(colourpicker)    #Colours: used for colour selection

library(shinyjs)         # to enable javascript functionality

library(tidyverse)       # Data Manipulation library

library(DT)              # Show Tabular Data

library(shinyjs)         # Shiny javascript enabler

library(shinyWidgets)    # Shiny Widgets

library(shinycssloaders) # CSS loaders 

library(htmltools)       # html tools for shiny

library(plotly)          # plotly 

library(RColorBrewer)    # Color Platelate  

library(shinythemes)     # Shiny Themes library

library(shinydashboardPlus) # add-on for shiny

library(waiter)             # loading screens with spinners

library(shinydashboard)     # Dashboard Element

library(dashboardthemes)    # Dashboard Themes

library(shinyjqui)          # SHiny Widget 

library(shinyBS)            # Shiny Bootstrap Modal




# Competition Stats Global ----

source(file.path("Competition_Insights_Page_global.R"),  local = TRUE)$value


# Manager Insights Global ----
source(file.path("Manager_Insights_Page_global.R"),  local = TRUE)$value


# Player Insights Global -----

source(file.path("Player_Insights_Page_global.R"),  local = TRUE)$value





