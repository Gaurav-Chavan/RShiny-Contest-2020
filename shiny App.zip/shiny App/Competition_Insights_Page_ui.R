tabsetPanel(type ="pills",
            
            tabPanel("Group Stage",
                     br(),
                     br(),
                     
                     fluidRow(
                       column(6,
                              withSpinner(plotlyOutput("comp_grp_1"),type = 5)
                       ),
                       column(6,
                              withSpinner(ui_element = plotlyOutput("comp_grp_2"),type = 5)
                       )
                       
                       
                     ), # end fluid Row
                     br(),
                     br(),
                     fluidRow(
                       
                       column(6,align='center',
                              actionBttn("Show7",label = " Show Top Players",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_7", "Top Appearing Players in Group Stages", "Show7", size = "large",
                                      uiOutput("Top_Player_grp"))
                              
                              
                       ),
                       column(6,align='center',
                              actionBttn("Show8",label = " Show Group Stage Data",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_8", "Group Stage Data", "Show8", size = "large",
                                      DT::dataTableOutput("table5")
                              )      
                       )
                       
                     ) # end fluid Row
                     
                     
                     
            ), # End Tab Panel          
            
            tabPanel("Round 16",
                     br(),
                     br(),
                     
                     fluidRow(
                       column(6,
                              withSpinner(plotlyOutput("comp_r16_1"),type = 5)
                       ),
                       column(6,
                              withSpinner(ui_element = plotlyOutput("comp_r16_2"),type = 5)
                       )
                       
                       
                     ), # end fluid Row
                     br(),
                     br(),
                     fluidRow(
                       
                       column(6,align='center',
                              actionBttn("Show9",label = " Show Top Players",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_9", "Top Appearing Players in Round 16", "Show9", size = "large",
                                      uiOutput("Top_Player_r16"))
                              
                              
                       ),
                       column(6,align='center',
                              actionBttn("Show10",label = " Show Round 16 Data",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_10", "Round 16 Data", "Show10", size = "large",
                                      DT::dataTableOutput("table4")
                              )      
                       )
                       
                     ) # end fluid Row
                     
                     
                     
            ), # End Tab Panel          
            
            
            tabPanel("Quater Finals",
                     br(),
                     br(),
                     
                     fluidRow(
                       column(6,
                              withSpinner(plotlyOutput("comp_quarter_final_1"),type = 5)
                       ),
                       column(6,
                              withSpinner(ui_element = plotlyOutput("comp_quarter_final_2"),type = 5)
                       )
                       
                       
                     ), # end fluid Row
                     br(),
                     br(),
                     fluidRow(
                       
                       column(6,align='center',
                              actionBttn("Show3",label = " Show Top Players",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_3", "Top Appearing Players in Quarter Final", "Show3", size = "large",
                                      uiOutput("Top_Player_Quarter_Final"))
                              
                              
                       ),
                       column(6,align='center',
                              actionBttn("Show4",label = " Show Quarter Final Data",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_4", "Quarter Final Data", "Show4", size = "large",
                                      DT::dataTableOutput("table2")
                              )      
                       )
                       
                     ) # end fluid Row
                     
                     
                     
            ), # End Tab Panel
            
            tabPanel("Semi Finals",
                     br(),
                     br(),
                     fluidRow(
                       column(6,
                              withSpinner(plotlyOutput("comp_semi_final_1"),type = 5)
                       ),
                       column(6,
                              withSpinner(ui_element = plotlyOutput("comp_semi_final_2"),type = 5)
                       )
                       
                       
                     ), # end fluid Row
                     br(),
                     br(),
                     fluidRow(
                       
                       column(6,align='center',
                              actionBttn("Show5",label = " Show Top Players",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_5", "Top Appearing Players in Semi Finals", "Show5", size = "large",
                                      uiOutput("Top_Player_Semi_Final"))
                              
                              
                       ),
                       column(6,align='center',
                              actionBttn("Show6",label = " Show Semi Finale Data",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_6", "Semi Finale Data Table", "Show6", size = "large",
                                      DT::dataTableOutput("table3")
                              )      
                       )
                       
                     ) # end fluid Row
                     
                     
            ),
            
            tabPanel("Finals",
                     br(),
                     br(),
                     fluidRow(
                       column(6,
                              withSpinner(plotlyOutput("comp_final_1"),type = 5)
                       ),
                       column(6,
                              withSpinner(ui_element = plotlyOutput("comp_final_2"),type = 5)
                       )
                       
                       
                     ), # end fluid Row
                     br(),
                     br(),
                     fluidRow(
                       
                       column(6,align='center',
                              actionBttn("Show1",label = " Show Top Players",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_1", "Top Appearing Players in Finale", "Show1", size = "large",
                                      uiOutput("Top_Player_Final"))
                              
                              
                       ),
                       column(6,align='center',
                              actionBttn("Show2",label = " Show Finale Data",style = "unite",  color = "default",
                                         size = "md",
                                         block = FALSE,
                                         no_outline = TRUE),
                              
                              bsModal("modalExample_2", "Finale Data Table", "Show2", size = "large",
                                      DT::dataTableOutput("table1")
                              )      
                       )
                       
                     ) # end fluid Row
                     
                     
            ) # End TabPanel
            
) # End Tabset Panel