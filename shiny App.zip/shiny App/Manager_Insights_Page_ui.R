tabItem("Manager_Stats",
br(),
br(),
fluidRow(
  column(6,
         withSpinner(plotlyOutput("manager_1"),type = 5)
  ),
  column(6,
         withSpinner(ui_element = plotlyOutput("manager_2"),type = 5)
  )
  
  
), # end fluid Row
br(),
br(),
fluidRow(
  
  column(6,align='center',
         actionBttn("mg1",label = "Manager Nationalities",style = "unite",  color = "default",
                    size = "md",
                    block = FALSE,
                    no_outline = TRUE),
         
         bsModal("mg_modal_1", "Nations where Most Managers Belong", "mg1", size = "large",
                 uiOutput("Manager_UI"))
         
         
  ),
  column(6,align='center',
         actionBttn("mg2",label = " Show Manager Records",style = "unite",  color = "default",
                    size = "md",
                    block = FALSE,
                    no_outline = TRUE),
         
         bsModal("mg_modal_2", "Manager's History", "mg2", size = "large",
                 DT::dataTableOutput("table_mgr")
         )      
  )
  
) # end fluid Row

)