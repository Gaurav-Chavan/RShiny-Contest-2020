# Players Who Made Most Appearnce ----

All_time_appearance <<- read_csv("Data File/Player Stats/All_time_appearance.csv")


All_time_appearance_1 <- All_time_appearance %>% 
  filter(Total_Appearance > 120) %>%
  arrange(Total_Appearance) %>%
  mutate(Player_Name = factor(Player_Name, levels = .$Player_Name))


# Players who scored Most Hatrics ----

All_time_Hat_Tricks <<- read_csv("Data File/Player Stats/All_time_Hat_Tricks.csv")


# Plot 1 : Lolipop Chart to show Hatricks

All_time_Hat_Tricks1 <- All_time_Hat_Tricks %>% 
  arrange(`Hat Tricks`) %>%
  top_n(10) %>% 
  mutate(Player_Name = factor(Players, levels = .$Players))



# Players Who Made Most Assists ----

All_time_Leading_Assists <<- read_csv("Data File/Player Stats/All_time_Leading_Assists.csv")


All_time_Leading_Assists_1 <- All_time_Leading_Assists %>% 
  filter(Assists > 20) %>%
  arrange(Assists) %>%
  mutate(Player_Name = factor(`Assist name`, levels = .$`Assist name`))


# All_time_Leading_Scorers ----

All_time_Leading_Scorers <<- read_csv("Data File/Player Stats/All_time_Leading_Scorers.csv")



All_time_Leading_Scorers_1 <- All_time_Leading_Scorers %>% 
  filter(Goals > 50) %>%
  arrange(Goals) %>%
  mutate(Player_Name = factor(Player_Name, levels = .$Player_Name))





#xxxxxxxxxxxxxxxxxxx Ugly SIde ----


# All Time Red ----

All_TIme_red <<- read_csv("Data File/Player Stats/All_TIme_red.csv")

All_TIme_red <- All_TIme_red %>% 
  filter(Red_Card > 2)


# All Time yellow ----

All_TIme_yellow <<- read_csv("Data File/Player Stats/All_TIme_yellow.csv")

All_TIme_yellow <-  All_TIme_yellow %>% 
  filter(Yellow_Card > 24)

All_TIme_yellow <- All_TIme_yellow[complete.cases(All_TIme_yellow),]



# ---------------- Most Stats --------------------#

# Most Goal Scoroer in a Match  ----

MostPlayerGoalsScorerInMatch <<- read_csv("Data File/Most_Stats/MostPlayerGoalsScorerInMatch.csv")

MostPlayerGoalsScorerInMatch_1 <- MostPlayerGoalsScorerInMatch %>% 
  arrange(Goals) %>%
  filter(Goals  > 3)  %>% 
  mutate(Player_Name  = factor(Players))





# Most Goal Scoroer in a Season  ----

MostGoalsScorerInSeason <<- read_csv("Data File/Most_Stats/MostGoalsScorerInSeason.csv")

MostGoalsScorerInSeason_1 <- MostGoalsScorerInSeason %>% 
  arrange(Goals) %>%
  filter(Goals  > 10)  %>% 
  mutate(Rank  = factor(Rank , levels = .$Rank ))



# Team Most Goal in a Match ----

MostGoalsScorerInMatch <<- read_csv("Data File/Most_Stats/MostGoalsScorerInMatch.csv")


MostGoalsScorerInMatch_1 <- MostGoalsScorerInMatch %>% 
  arrange(Goals) %>%
  mutate(Rank  = factor(Rank , levels = .$Rank ))

