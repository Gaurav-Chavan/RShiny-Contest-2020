# Manager Stats Server ----

output$manager_1 <-  renderPlotly({
  # Versatile clubs Plot ----
  
  mp1 <- ggplot(Most_Versatile_Clubs, aes(x=reorder(Club_Associated,Manager_count), 
                                          y=Manager_count,
                                          text = paste('Club Name : ', Most_Versatile_Clubs$Club_Associated,
                                                       '<br>Count of Managers : ', Most_Versatile_Clubs$Manager_count
                                          ) 
                                          
  )) + 
    geom_point(col="tomato2", size=3) +   # Draw points
    theme_light() +
    geom_segment(aes(x=Club_Associated, 
                     xend=Club_Associated, 
                     y=min(Manager_count), 
                     yend=max(Manager_count)), 
                 linetype="dashed", 
                 size=0.1) +   # Draw dashed lines
    labs(title="Club with Versatile Managers") +  
    coord_flip() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank(),
      axis.title.y = element_blank()
      
    )
  
  ggplotly(mp1,tooltip = "text")
  
})

output$manager_2 <-  renderPlotly({
  
  #  Managers basis WIn %  ---
  
  # Plot 1 : Lolipop Chart to show top 10 Managers  basis Win
  
  Top_10_manager <- AllTimeManagersTable %>%
    arrange(`Win %`) %>%
    top_n(10) %>%
    mutate(Club = factor(Manager_Name, levels = .$Manager_Name),
           `Win %` = as.numeric(str_remove(`Win %`,pattern = "%"))  
    )
  
  
  pm1 <- ggplot(Top_10_manager, aes(x = Manager_Name,
                                    y = `Win %`,
                                    text = paste('Manager Name : ', Top_10_manager$Manager_Name,
                                                 '<br>Win % : ', Top_10_manager$`Win %`
                                    )
  )) +
    geom_segment( aes(x=Manager_Name, xend=Manager_Name, y=0, yend=`Win %`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Manager Name") +
    ylab("Win %") +
    ggtitle("Top 10 Managers Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
    )
  
  ggplotly(pm1,tooltip = c("text"))
  
  
  
})


output$manager_nationality <-  DT::renderDataTable(
  
  AllTimeManagers_Nationalities,
  options = list(columnDefs = list(list(className = 'dt-center', targets = 3)))
  
)

output$image1 <- renderImage({
  list(src = "www/Rplot.png"
  )
}, deleteFile = TRUE)



output$Manager_UI <-  renderUI({
  
  fluidRow(
    
    imageOutput('image1')
    
    
  )
  br()
  fluidRow(
    actionBttn("mg3",label = "Manager's Nationality",style = "unite",  color = "default",
               size = "md",
               block = FALSE,
               no_outline = TRUE),
    
    bsModal("mg_modal_3", "Manager's Nationality Data", "mg3", size = "large",
            DT::dataTableOutput("manager_nationality")
            
    )  
    
    
  )
  
  
}) # End RenderUI

output$table_mgr <- DT::renderDataTable(AllTimeManagersTable,
                                        options = list(
                                          columnDefs = list(list(className = 'dt-center', targets = 12)))
                                        
)