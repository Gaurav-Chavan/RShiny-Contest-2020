# Group Stage ----

output$comp_grp_1 <- renderPlotly({
  
  # Plot 1 : Lolipop Chart to show top 10 teams  basis competition stage
  
  All_TIme_Competition_Record_grp1 <- All_TIme_Competition_Record_grp %>% 
    arrange(`Matches Played`) %>%
    top_n(10) %>% 
    mutate(`Club Name` = factor(`Club Name`, levels = .$`Club Name`))
  
  
  f1 <- ggplot(All_TIme_Competition_Record_grp1, aes(x=All_TIme_Competition_Record_grp1$`Club Name`, 
                                                     y=All_TIme_Competition_Record_grp1$`Matches Played`,
                                                     text = paste('Club Name : ', All_TIme_Competition_Record_grp1$`Club Name`,
                                                                  '<br>Matches Played : ', All_TIme_Competition_Record_grp1$`Matches Played`
                                                     ) 
  )) +
    geom_segment( aes(x=All_TIme_Competition_Record_grp1$`Club Name`, xend=All_TIme_Competition_Record_grp1$`Club Name`, y=0, yend=All_TIme_Competition_Record_grp1$`Matches Played`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Club Name") +
    ylab("Matches Played") +
    ggtitle("Top 10 Teams Basis Matches Played") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
})

output$comp_grp_2 <- renderPlotly({
  
  # Bar Plot Showing Top teams with Win % ----
  All_TIme_Competition_Record_r16$Won <- as.numeric(All_TIme_Competition_Record_r16$Won)
  
  
  All_TIme_Competition_Record_r162 <- All_TIme_Competition_Record_r16 %>% 
    mutate(`Win %`= round(((Won / `Matches Played`)*100),digits = 2 ))  %>%  
    filter(`Win %` > 50) %>%
    arrange(`Win %`) %>%
    mutate(Club = factor(`Club Name`, levels = .$`Club Name`))
  
  # Reverse side
  f2 <-  All_TIme_Competition_Record_r162 %>%
    mutate(name = fct_reorder(Club, desc(`Win %`))) %>%
    ggplot( aes(x=`Club Name`, 
                y=`Win %`,
                text = paste('Club Name : ', All_TIme_Competition_Record_r162$`Club Name`,
                             '<br>Matches Played : ',All_TIme_Competition_Record_r162$`Matches Played`,
                             '<br>Win % : ', All_TIme_Competition_Record_r162$`Win %`
                ) 
    )) +
    geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Teams") +
    theme_light() +
    ggtitle(" Teams Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

output$Top_Player_grp <-  renderUI({
  
  box(
    title = "Top Players",
    status = "info",
    width = 12,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          selectInput(inputId = 'e5','Select Position',
                      choices  = unique(All_time_players_grps_1$Position)
          )
        )
      ),
      column(
        width = 8,
        withSpinner(plotlyOutput("comp_grp_3"),type = 5)
      )
    ) # End FluidRow
  ) # End Box
  
  
}) # End RenderUI

# Observe Event For Plot ----
observeEvent(input$e5,{
  
  Position1 <- input$e5
  
  output$comp_grp_3 <- renderPlotly({
    
    ## Filter add Position ----
    All_time_players_grps_2 <-   All_time_players_grps_1 %>% 
      filter(Position == Position1)
    
    
    comp_grp_31 <-  ggplot(data=All_time_players_grps_2, aes(x=reorder(Player_Name,Total_Appearance), 
                                                             y=Total_Appearance,
                                                             text = paste(All_time_players_grps_2$Player_Name,
                                                                          '<br>Total Appearance : ', All_time_players_grps_2$Total_Appearance
                                                             )
    )) +
      geom_bar(stat="identity", fill="steelblue") +
      theme_light() +
      xlab("") +
      ylab("Appearance") +
      coord_flip() +
      ggtitle("Players with most apperance") +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank()
      )
    
    ggplotly(comp_grp_31,tooltip = c("text"))
    
    
    
  })
  
})

# Show Table ----

output$table5 <- DT::renderDataTable(All_TIme_Competition_Record_grp,
                                     options = list(
                                       columnDefs = list(list(className = 'dt-center', targets = 8)))
                                     
)



# Round 16 ----

output$comp_r16_1 <- renderPlotly({
  
  # Plot 1 : Lolipop Chart to show top 10 teams  basis competition stage
  
  All_TIme_Competition_Record_r161 <- All_TIme_Competition_Record_r16 %>% 
    arrange(`Matches Played`) %>%
    top_n(10) %>% 
    mutate(`Club Name` = factor(`Club Name`, levels = .$`Club Name`))
  
  
  f1 <- ggplot(All_TIme_Competition_Record_r161, aes(x=All_TIme_Competition_Record_r161$`Club Name`, 
                                                     y=All_TIme_Competition_Record_r161$`Matches Played`,
                                                     text = paste('Club Name : ', All_TIme_Competition_Record_r161$`Club Name`,
                                                                  '<br>Matches Played : ', All_TIme_Competition_Record_r161$`Matches Played`
                                                     ) 
  )) +
    geom_segment( aes(x=All_TIme_Competition_Record_r161$`Club Name`, xend=All_TIme_Competition_Record_r161$`Club Name`, y=0, yend=All_TIme_Competition_Record_r161$`Matches Played`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Club Name") +
    ylab("Matches Played") +
    ggtitle("Top 10 Teams Basis Matches Played") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
})

output$comp_r16_2 <- renderPlotly({
  
  # Bar Plot Showing Top teams with Win % ----
  All_TIme_Competition_Record_r16$Won <- as.numeric(All_TIme_Competition_Record_r16$Won)
  
  
  All_TIme_Competition_Record_r162 <- All_TIme_Competition_Record_r16 %>% 
    mutate(`Win %`= round(((Won / `Matches Played`)*100),digits = 2 ))  %>%  
    filter(`Win %` > 40) %>%
    arrange(`Win %`) %>%
    mutate(Club = factor(`Club Name`, levels = .$`Club Name`))
  
  # Reverse side
  f2 <-  All_TIme_Competition_Record_r162 %>%
    mutate(name = fct_reorder(`Club Name`, desc(`Win %`))) %>%
    ggplot( aes(x=`Club Name`, 
                y=`Win %`,
                text = paste('Club Name : ', All_TIme_Competition_Record_r162$`Club Name`,
                             '<br>Matches Played : ',All_TIme_Competition_Record_r162$`Matches Played`,
                             '<br>Win % : ', All_TIme_Competition_Record_r162$`Win %`
                ) 
    )) +
    geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Teams") +
    theme_light() +
    ggtitle(" Teams Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

output$Top_Player_r16 <-  renderUI({
  
  box(
    title = "Top Players",
    status = "info",
    width = 12,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          selectInput(inputId = 'e4','Select Position',
                      choices  = unique(All_time_players_r16_1$Position)
          )
        )
      ),
      column(
        width = 8,
        withSpinner(plotlyOutput("comp_r16_3"),type = 5)
      )
    ) # End FluidRow
  ) # End Box
  
  
}) # End RenderUI

# Observe Event For Plot ----
observeEvent(input$e4,{
  
  Position1 <- input$e4
  
  output$comp_r16_3 <- renderPlotly({
    
    ## Filter add Position ----
    All_time_players_r16_2 <-   All_time_players_r16_1 %>% 
      filter(Position == Position1)
    
    
    comp_r16_31 <-  ggplot(data=All_time_players_r16_2, aes(x=reorder(Player_Name,Total_Appearance), 
                                                            y=Total_Appearance,
                                                            text = paste(All_time_players_r16_2$Player_Name,
                                                                         '<br>Total Appearance : ', All_time_players_r16_2$Total_Appearance
                                                            )
    )) +
      geom_bar(stat="identity", fill="steelblue") +
      theme_light() +
      xlab("") +
      ylab("Appearance") +
      coord_flip() +
      ggtitle("Players with most apperance") +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank()
      )
    
    ggplotly(comp_r16_31,tooltip = c("text"))
    
    
    
  })
  
})

# Show Table ----

output$table4 <- DT::renderDataTable(All_TIme_Competition_Record_r16,
                                     options = list(
                                       columnDefs = list(list(className = 'dt-center', targets = 6)))
                                     
)



# Quarter Final ----

output$comp_quarter_final_1 <- renderPlotly({
  
  # Plot 1 : Lolipop Chart to show top 10 teams  basis competition stage
  
  All_time_Competition_Record_Quarter_finals1 <- All_time_Competition_Record_Quarter_finals %>% 
    arrange(`Matches_played,`) %>%
    top_n(10) %>% 
    mutate(Club = factor(Club, levels = .$Club))
  
  
  f1 <- ggplot(All_time_Competition_Record_Quarter_finals1, aes(x=All_time_Competition_Record_Quarter_finals1$Club, 
                                                                y=All_time_Competition_Record_Quarter_finals1$`Matches_played,`,
                                                                text = paste('Club Name : ', All_time_Competition_Record_Quarter_finals1$Club,
                                                                             '<br>Matches Played : ', All_time_Competition_Record_Quarter_finals1$`Matches_played,`
                                                                ) 
  )) +
    geom_segment( aes(x=All_time_Competition_Record_Quarter_finals1$Club, xend=All_time_Competition_Record_Quarter_finals1$Club, y=0, yend=All_time_Competition_Record_Quarter_finals1$`Matches_played,`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Club Name") +
    ylab("Matches Played") +
    ggtitle("Top 10 Teams Basis Matches Played") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
})

output$comp_quarter_final_2 <- renderPlotly({
  
  # Bar Plot Showing Top teams with Win % ----
  All_time_Competition_Record_Quarter_finals$Won <- as.numeric(All_time_Competition_Record_Quarter_finals$Won)
  
  
  All_time_Competition_Record_Quarter_finals2 <- All_time_Competition_Record_Quarter_finals %>% 
    mutate(`Win %`= round(((Won / `Matches_played,`)*100),digits = 2 ))  %>%  
    filter(`Win %` > 40) %>%
    arrange(`Win %`) %>%
    mutate(Club = factor(Club, levels = .$Club))
  
  # Reverse side
  f2 <-  All_time_Competition_Record_Quarter_finals2 %>%
    mutate(name = fct_reorder(Club, desc(`Win %`))) %>%
    ggplot( aes(x=Club, 
                y=`Win %`,
                text = paste('Club Name : ', All_time_Competition_Record_Quarter_finals2$Club,
                             '<br>Matches Played : ',All_time_Competition_Record_Quarter_finals2$`Matches_played,`,
                             '<br>Win % : ', All_time_Competition_Record_Quarter_finals2$`Win %`
                ) 
    )) +
    geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Teams") +
    theme_light() +
    ggtitle(" Teams Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

output$Top_Player_Quarter_Final <-  renderUI({
  
  box(
    title = "Top Players",
    status = "info",
    width = 12,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          selectInput(inputId = 'e2','Select Position',
                      choices  = unique(All_time_players_Quarter_final_1$Position)
          )
        )
      ),
      column(
        width = 8,
        withSpinner(plotlyOutput("comp_quarter_final_3"),type = 5)
      )
    ) # End FluidRow
  ) # End Box
  
  
}) # End RenderUI

# Observe Event For Plot ----
observeEvent(input$e2,{
  
  Position1 <- input$e2
  
  output$comp_quarter_final_3 <- renderPlotly({
    
    ## Filter add Position ----
    All_time_players_Quarter_final_2 <-   All_time_players_Quarter_final_1 %>% 
      filter(Position == Position1)
    
    
    comp_quarter_final_31 <-  ggplot(data=All_time_players_Quarter_final_2, aes(x=reorder(Player_Name,Total_Appearance), 
                                                                                y=Total_Appearance,
                                                                                text = paste(All_time_players_Quarter_final_2$Player_Name,
                                                                                             '<br>Total Appearance : ', All_time_players_Quarter_final_2$Total_Appearance
                                                                                )
    )) +
      geom_bar(stat="identity", fill="steelblue") +
      theme_light() +
      xlab("") +
      ylab("Appearance") +
      coord_flip() +
      ggtitle("Players with most apperance") +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank()
      )
    
    ggplotly(comp_quarter_final_31,tooltip = c("text"))
    
    
    
  })
  
})

# Show Table ----

output$table2 <- DT::renderDataTable(All_time_Competition_Record_Quarter_finals,
                                     options = list(
                                       columnDefs = list(list(className = 'dt-center', targets = 6)))
                                     
)


# Semi Final ----

output$comp_semi_final_1 <- renderPlotly({
  
  # Plot 1 : Lolipop Chart to show top 10 teams  basis competition stage
  
  All_time_Competition_Record_Semi_finals1 <- All_time_Competition_Record_Semi_finals %>% 
    arrange(`Matches_played,`) %>%
    top_n(10) %>% 
    mutate(Club = factor(Club, levels = .$Club))
  
  
  f1 <- ggplot(All_time_Competition_Record_Semi_finals1, aes(x=All_time_Competition_Record_Semi_finals1$Club, 
                                                             y=All_time_Competition_Record_Semi_finals1$`Matches_played,`,
                                                             text = paste('Club Name : ', All_time_Competition_Record_Semi_finals1$Club,
                                                                          '<br>Matches Played : ', All_time_Competition_Record_Semi_finals1$`Matches_played,`
                                                             ) 
  )) +
    geom_segment( aes(x=All_time_Competition_Record_Semi_finals1$Club, xend=All_time_Competition_Record_Semi_finals1$Club, y=0, yend=All_time_Competition_Record_Semi_finals1$`Matches_played,`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Club Name") +
    ylab("Matches Played") +
    ggtitle("Top 10 Teams Basis Matches Played") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
})

output$comp_semi_final_2 <- renderPlotly({
  
  # Bar Plot Showing Top teams with Win % ----
  All_time_Competition_Record_Semi_finals$Won <- as.numeric(All_time_Competition_Record_Semi_finals$Won)
  
  
  All_time_Competition_Record_Semi_finals2 <- All_time_Competition_Record_Semi_finals %>% 
    mutate(`Win %`= round(((Won / `Matches_played,`)*100),digits = 2 ))  %>%  
    filter(`Win %` > 40) %>%
    arrange(`Win %`) %>%
    mutate(Club = factor(Club, levels = .$Club))
  
  # Reverse side
  f2 <-  All_time_Competition_Record_Semi_finals2 %>%
    mutate(name = fct_reorder(Club, desc(`Win %`))) %>%
    ggplot( aes(x=Club, 
                y=`Win %`,
                text = paste('Club Name : ', All_time_Competition_Record_Semi_finals2$Club,
                             '<br>Matches Played : ',All_time_Competition_Record_Semi_finals2$`Matches_played,`,
                             '<br>Win % : ', All_time_Competition_Record_Semi_finals2$`Win %`
                ) 
    )) +
    geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Teams") +
    theme_light() +
    ggtitle(" Teams Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

output$Top_Player_Semi_Final <-  renderUI({
  
  box(
    title = "Top Players",
    status = "info",
    width = 12,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          selectInput(inputId = 'e3','Select Position',
                      choices  = unique(All_time_players_Semi_final_1$Position)
          )
        )
      ),
      column(
        width = 8,
        withSpinner(plotlyOutput("comp_semi_final_3"),type = 5)
      )
    ) # End FluidRow
  ) # End Box
  
  
}) # End RenderUI

# Observe Event For Plot ----
observeEvent(input$e3,{
  
  Position1 <- input$e3
  
  output$comp_semi_final_3 <- renderPlotly({
    
    ## Filter add Position ----
    All_time_players_Semi_final_2 <-   All_time_players_Semi_final_1 %>% 
      filter(Position == Position1)
    
    
    comp_semi_final_31 <-  ggplot(data=All_time_players_Semi_final_2, aes(x=reorder(Players,Total), 
                                                                          y=Total,
                                                                          text = paste(All_time_players_Semi_final_2$Players,
                                                                                       '<br>Total Appearance : ', All_time_players_Semi_final_2$Total
                                                                          )
    )) +
      geom_bar(stat="identity", fill="steelblue") +
      theme_light() +
      xlab("") +
      ylab("Appearance") +
      coord_flip() +
      ggtitle("Players with most apperance") +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank()
      )
    
    ggplotly(comp_semi_final_31,tooltip = c("text"))
    
    
    
  })
  
})

# Show Table ----

output$table3 <- DT::renderDataTable(All_time_Competition_Record_Semi_finals,
                                     options = list(
                                       columnDefs = list(list(className = 'dt-center', targets = 6)))
                                     
)

# Final ----

output$comp_final_1 <- renderPlotly({
  
  # Plot 1 : Lolipop Chart to show top 10 teams  basis competition stage
  
  All_TIme_Competition_Record_Finals1 <- All_TIme_Competition_Record_Finals %>% 
    arrange(`Matches_played,`) %>%
    top_n(10) %>% 
    mutate(Club = factor(Club, levels = .$Club))
  
  
  f1 <- ggplot(All_TIme_Competition_Record_Finals1, aes(x=All_TIme_Competition_Record_Finals1$Club, 
                                                        y=All_TIme_Competition_Record_Finals1$`Matches_played,`,
                                                        text = paste('Club Name : ', All_TIme_Competition_Record_Finals1$Club,
                                                                     '<br>Matches Played : ', All_TIme_Competition_Record_Finals1$`Matches_played,`
                                                        ) 
  )) +
    geom_segment( aes(x=All_TIme_Competition_Record_Finals1$Club, xend=All_TIme_Competition_Record_Finals1$Club, y=0, yend=All_TIme_Competition_Record_Finals1$`Matches_played,`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Club Name") +
    ylab("Matches Played") +
    ggtitle("Top 10 Teams Basis Matches Played") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
})

output$comp_final_2 <- renderPlotly({
  
  # Bar Plot Showing Top teams with Win % ----
  
  All_TIme_Competition_Record_Finals2 <- All_TIme_Competition_Record_Finals %>% 
    mutate(`Win %`= round(((Won / `Matches_played,`)*100),digits = 2 ))  %>%  
    filter(`Win %` > 0) %>%
    arrange(`Win %`) %>%
    mutate(Club = factor(Club, levels = .$Club))
  
  # Reverse side
  f2 <-  All_TIme_Competition_Record_Finals2 %>%
    mutate(name = fct_reorder(Club, desc(`Win %`))) %>%
    ggplot( aes(x=Club, 
                y=`Win %`,
                text = paste('Club Name : ', All_TIme_Competition_Record_Finals2$Club,
                             '<br>Matches Played : ',All_TIme_Competition_Record_Finals2$`Matches_played,`,
                             '<br>Win % : ', All_TIme_Competition_Record_Finals2$`Win %`
                ) 
    )) +
    geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Teams") +
    theme_light() +
    ggtitle(" Teams Basis Win %") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

output$Top_Player_Final <-  renderUI({
  
  box(
    title = "Top Players",
    status = "info",
    width = 12,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          selectInput(inputId = 'e1','Select Position',
                      choices  = unique(All_time_players_final$Position)
          )
        )
      ),
      column(
        width = 8,
        withSpinner(plotlyOutput("comp_final_3"),type = 5)
      )
    ) # End FluidRow
  ) # End Box
  
  
}) # End RenderUI

# Observe Event For Plot ----
observeEvent(input$e1,{
  
  Position1 <- input$e1
  
  output$comp_final_3 <- renderPlotly({
    
    ## Filter add Position ----
    All_time_players_final_2 <-   All_time_players_final_1 %>% 
      filter(Position == Position1)
    
    
    comp_final_31 <-  ggplot(data=All_time_players_final_2, aes(x=reorder(Player_Name,Total_Appearance), 
                                                                y=Total_Appearance,
                                                                text = paste(All_time_players_final_2$Player_Name,
                                                                             '<br>Total Appearance : ', All_time_players_final_2$Total_Appearance
                                                                )
    )) +
      geom_bar(stat="identity", fill="steelblue") +
      theme_light() +
      xlab("") +
      ylab("Appearance") +
      coord_flip() +
      ggtitle("Players with most apperance") +
      theme(
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank()
      )
    
    ggplotly(comp_final_31,tooltip = c("text"))
    
    
    
  })
  
})

# Show Table ----

output$table1 <- DT::renderDataTable(All_TIme_Competition_Record_Finals,
                                     options = list(
                                       columnDefs = list(list(className = 'dt-center', targets = 6)))
                                     
)

