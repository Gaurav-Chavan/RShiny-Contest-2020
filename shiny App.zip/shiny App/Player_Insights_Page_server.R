
#  Most Number of Appearances  Plot ---- 
output$player_g1 <- renderPlotly({
  
  f2 <-  All_time_appearance_1 %>%
    mutate(name = fct_reorder(Player_Name, desc(Total_Appearance))) %>%
    ggplot( aes(x=reorder(Player_Name,Total_Appearance),
                y=Total_Appearance,
                text = paste('Player Name : ', All_time_appearance_1$Player_Name,
                             '<br>Appearance : ',All_time_appearance_1$Total_Appearance,
                             '<br>Goals_Scored  : ', All_time_appearance_1$Goals_Scored
                ) 
    )) +
    geom_bar(stat="identity", fill="#128dbc", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Player") +
    theme_light() +
    ggtitle("Most Number of Appearances ") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
})

#  Most Number of Appearances Table  ---- 
output$p1_table <- DT::renderDataTable(All_time_appearance,
                                       options = list(
                                         columnDefs = list(list(className = 'dt-center', targets = 8)))
                                       
)

# Most Hat-Tricks Plot ---

output$player_g2 <- renderPlotly(({
  
  f1 <- ggplot(All_time_Hat_Tricks1, aes(x=All_time_Hat_Tricks1$Player_Name, 
                                         y=All_time_Hat_Tricks1$`Hat Tricks`,
                                         text = paste('Player Name : ', All_time_Hat_Tricks1$Player_Name,
                                                      '<br># Hatricks : ', All_time_Hat_Tricks1$`Hat Tricks`
                                         ) 
  )) +
    geom_segment( aes(x=All_time_Hat_Tricks1$Player_Name, xend=All_time_Hat_Tricks1$Player_Name, y=0, yend=All_time_Hat_Tricks1$`Hat Tricks`), color="skyblue") +
    geom_point( color="blue", size=4, alpha=0.6) +
    theme_light() +
    coord_flip() +
    xlab("Player Name") +
    ylab("Number of Hatricks") +
    ggtitle("Hatrick Takers") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  ggplotly(f1,tooltip = c("text"))
  
  
}))

#  Most Number of Hat-Tricks Table  ---- 
output$p2_table <- DT::renderDataTable(All_time_Hat_Tricks,
                                       options = list(
                                         columnDefs = list(list(className = 'dt-center', targets = 3)))
                                       
)

# Most Assists Plot ----

output$player_g3 <-  renderPlotly({
  
  # Reverse side
  f2 <-  All_time_Leading_Assists_1 %>%
    mutate(name = fct_reorder(Player_Name, desc(Assists))) %>%
    ggplot( aes(x=reorder(Player_Name,Assists),
                y=Assists,
                text = paste('Player Name : ', All_time_Leading_Assists_1$Player_Name,
                             '<br>Assists : ',All_time_Leading_Assists_1$Assists
                ) 
    )) +
    geom_bar(stat="identity", fill="#197498", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Player") +
    theme_light() +
    ggtitle(" All Time  Assists") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
  
  
})

#  Most Number of Assists Table  ---- 
output$p3_table <- DT::renderDataTable(All_time_Leading_Assists,
                                       options = list(
                                         columnDefs = list(list(className = 'dt-center', targets = 3)))
                                       
)

# Most Goals ----

output$player_g4 <- renderPlotly({
  
  # Reverse side
  f2 <-  All_time_Leading_Scorers_1 %>%
    mutate(name = fct_reorder(Player_Name, desc(Goals))) %>%
    ggplot( aes(x=reorder(Player_Name,Goals),
                y=Goals,
                text = paste('Player Name : ', All_time_Leading_Scorers_1$Player_Name,
                             '<br>Goals : ',All_time_Leading_Scorers_1$Goals
                ) 
    )) +
    geom_bar(stat="identity", fill="#197498", alpha=.6, width=.4) +
    coord_flip() +
    xlab("Player") +
    theme_light() +
    ggtitle("Leading Goal Scorers") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

#  Most Goals Table  ---- 
output$p4_table <- DT::renderDataTable(All_time_Leading_Scorers,
                                       options = list(
                                         columnDefs = list(list(className = 'dt-center', targets = 9)))
                                       
)


# ---------------- Ugly Side ----------------------


# Most Red cards ----

output$red_c <- renderPlotly({
  
  # Reverse side
  f2 <-  All_TIme_red %>%
    mutate(name = fct_reorder(Player_Name  , desc(Red_Card ))) %>%
    ggplot( aes(x=reorder(Player_Name ,Red_Card ),
                y=Red_Card,
                text = paste('Player Name : ', All_TIme_red$Player_Name,
                             '<br>Red Card : ',All_TIme_red$Red_Card
                ) 
    )) +
    geom_bar(stat="identity", fill="#f3423c", alpha=.6, width=.4) +
    coord_flip() +
    xlab(" ") +
    theme_light() +
    ggtitle("Most Red Card") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})


# Table 
output$red_table <- DT::renderDataTable(All_TIme_red,
                                        options = list(
                                          columnDefs = list(list(className = 'dt-center', targets = 2)))
                                        
)


# Most Yellow Cards ----

output$yellow_c <- renderPlotly({
  
  # Reverse side
  f2 <-  All_TIme_yellow %>%
    mutate(name = fct_reorder(Player_Name  , desc(Yellow_Card ))) %>%
    ggplot( aes(x=reorder(Player_Name ,Yellow_Card ),
                y=Yellow_Card,
                text = paste('Player Name : ', All_TIme_yellow$Player_Name,
                             '<br>Yellow Card : ',All_TIme_yellow$Yellow_Card
                ) 
    )) +
    geom_bar(stat="identity", fill="#e9e700", width=.4) +
    coord_flip() +
    xlab(" ") +
    theme_light() +
    ggtitle("Most Yellow Card") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
  
})


# Table 
output$yellow_table <- DT::renderDataTable(All_TIme_yellow,
                                           options = list(
                                             columnDefs = list(list(className = 'dt-center', targets = 2)))
                                           
)



# ---------------------------- Most Stats ------

# Most Goal in Match ----

output$most_goal_match <- renderPlotly({
  
  # Reverse side
  f2 <-  MostPlayerGoalsScorerInMatch_1 %>%
    mutate(name = fct_reorder(Player_Name , desc(Goals))) %>%
    ggplot( aes(x=reorder(Player_Name ,Goals),
                y=Goals,
                text = paste('Player Name : ', MostPlayerGoalsScorerInMatch_1$Player_Name,
                             '<br>Date : ',MostPlayerGoalsScorerInMatch_1$Date,
                             '<br>Goals : ',MostPlayerGoalsScorerInMatch_1$Goals
                ) 
    )) +
    geom_bar(stat="identity", fill="#197498", alpha=.6, width=.4) +
    coord_flip() +
    xlab(" ") +
    theme_light() +
    ggtitle("Top Goal Scorers in a Match") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
})

# table 

output$most_goal_m_table <- DT::renderDataTable(MostPlayerGoalsScorerInMatch ,
                                                options = list(
                                                  columnDefs = list(list(className = 'dt-center', targets = 6)))
                                                
)



# Most Goal Scorer Season ----

output$most_goal_season <-  renderPlotly({
  
  # Reverse side
  f2 <-  MostGoalsScorerInSeason_1 %>%
    mutate(name = fct_reorder(Rank , desc(Goals))) %>%
    ggplot( aes(x=reorder(Rank ,Goals),
                y=Goals,
                text = paste('Player Name : ', MostGoalsScorerInSeason_1$Players,
                             '<br>Season : ',MostGoalsScorerInSeason_1$Competition,
                             '<br>Goals : ',MostGoalsScorerInSeason_1$Goals
                ) 
    )) +
    geom_bar(stat="identity", fill="#197498", alpha=.6, width=.4) +
    coord_flip() +
    xlab(" ") +
    theme_light() +
    ggtitle("Top Seasonal Goal Scorers") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
})

# Table
output$most_goal_season_table <- DT::renderDataTable(MostGoalsScorerInSeason ,
                                                     options = list(
                                                       columnDefs = list(list(className = 'dt-center', targets = 6)))
                                                     
)


# Team  Level Goals ----

output$most_goal_team <- renderPlotly({
  
  # Reverse side
  f2 <-  MostGoalsScorerInMatch_1 %>%
    mutate(name = fct_reorder(Rank , desc(Goals))) %>%
    ggplot( aes(x=reorder(Rank ,Goals),
                y=Goals,
                text = paste('Club : ', MostGoalsScorerInMatch_1$Clubs,
                             '<br>VS Club : ',MostGoalsScorerInMatch_1$`VS Club`,
                             '<br>Date : ',MostGoalsScorerInMatch_1$Date,
                             '<br>Goals : ',MostGoalsScorerInMatch_1$Goals
                ) 
    )) +
    geom_bar(stat="identity", fill="#197498", alpha=.6, width=.4) +
    coord_flip() +
    xlab(" ") +
    theme_light() +
    ggtitle("Top Matches basis Goals") +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_blank(),
      axis.ticks.y = element_blank(),
      axis.text.y = element_blank()
      
    )
  
  
  ggplotly(f2,tooltip = c("text"))
  
  
  
  
})


# Table 
output$most_goal_team_table <- DT::renderDataTable(MostGoalsScorerInMatch ,
                                                   options = list(
                                                     columnDefs = list(list(className = 'dt-center', targets = 6)))
                                                   
)
