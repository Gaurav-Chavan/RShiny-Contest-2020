
##Server (Start):====================================================================================

server = function(input, output, session) {
  
  Sys.sleep(3) # do something that takes time
  hide_waiter()
  
  
  # Competition Stats Server ----
  
  source(file.path("Competition_Insights_Page_server.R"),  local = TRUE)$value
  
  
  # Manager Stats Server ----
  
  source(file.path("Manager_Insights_Page_server.R"),  local = TRUE)$value
  
  # Player Stats Server ----
  
  source(file.path("Player_Insights_Page_server.R"),  local = TRUE)$value
  
  
  
  
} # End Server

