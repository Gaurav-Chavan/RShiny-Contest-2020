(
tabItem("Good_Side",
        fluidRow(
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Appearances",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "aqua-active",
                   closable = F,
                   br(),
                   plotlyOutput("player_g1"),
                   br(),
                   br(),
                   actionBttn("p11",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_11", "Most Appearnaces ", "p11", size = "large",
                           DT::dataTableOutput("p1_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ), # End Column
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Assists",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1510566337590-2fc1f21d0faa?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "yellow",
                   closable = F,
                   br(),
                   plotlyOutput("player_g3"),
                   br(),
                   br(),
                   actionBttn("p13",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_13", "Most Assists ", "p13", size = "large",
                           DT::dataTableOutput("p3_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ) # End Column
          
        ), # End Fluid Row
        br(),
        fluidRow(
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Hat Tricks",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1551958219-acbc608c6377?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "aqua-active",
                   closable = F,
                   br(),
                   plotlyOutput("player_g2"),
                   br(),
                   br(),
                   actionBttn("p12",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_12", "Most Hat-Tricks ", "p12", size = "large",
                           DT::dataTableOutput("p2_table")
                   )
                   
                   
                   
                 )
                 
                 
          ), # End Column
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Goal Scorers",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1517927033932-b3d18e61fb3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "orange",
                   closable = F,
                   br(),
                   plotlyOutput("player_g4"),
                   br(),
                   br(),
                   actionBttn("p14",label = "Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_14", "Most Hat-Tricks ", "p14", size = "large",
                           DT::dataTableOutput("p4_table")
                   )
                   
                   
                   
                 )
                 
                 
          ) # End Column
          
        ) # End Fluid Row
        
        
), # End Tab Item

tabItem("Ugly_Side",
        
        fluidRow(
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Red Cards",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1532396115384-4be6f5256898?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
                   color = "red",
                   closable = F,
                   br(),
                   plotlyOutput("red_c"),
                   br(),
                   br(),
                   actionBttn("r11",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_r_11", "Most Red Cards ", "r11", size = "large",
                           DT::dataTableOutput("red_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ), # End Column
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Yellow Card",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1556172437-098ec1038ce5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "yellow",
                   closable = F,
                   br(),
                   plotlyOutput("yellow_c"),
                   br(),
                   br(),
                   actionBttn("y13",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_y13", "Most Yellow Cards ", "y13", size = "large",
                           DT::dataTableOutput("yellow_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ) # End Column
          
        ) # End Fluid Row
        
        
),
br(),
tabItem("Most_Figures",
        
        fluidRow(
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Goals in a Match",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1577784768620-97247ed963f0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "blue",
                   closable = F,
                   br(),
                   plotlyOutput("most_goal_match"),
                   br(),
                   br(),
                   actionBttn("g11",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_g_11", "Data ", "g11", size = "large",
                           DT::dataTableOutput("most_goal_m_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ), # End Column
          
          column(6,align ='center',
                 widgetUserBox(
                   title = "Most Goal Scoroer in a Season",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1559019875-eaad55b75577?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "green",
                   closable = F,
                   br(),
                   plotlyOutput("most_goal_season"),
                   br(),
                   br(),
                   actionBttn("mg13",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_g_13", "Data ", "mg13", size = "large",
                           DT::dataTableOutput("most_goal_season_table")
                   ) 
                   
                   
                   
                 )
                 
                 
          ) # End Column
          
        ), # End Fluid Row
        br(),
        br(),
        fluidRow(
          
          column(12,align='center',
                 widgetUserBox(
                   title = "Most Goals by Teams in Match",
                   subtitle = "All Time",
                   type = NULL,
                   width = 12,
                   src = "https://images.unsplash.com/photo-1516567727245-ad8c68f3ec93?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
                   color = "yellow",
                   closable = F,
                   br(),
                   plotlyOutput("most_goal_team"),
                   br(),
                   br(),
                   actionBttn("mgt13",label = " Show  Data",style = "unite",  color = "default",
                              size = "md",
                              block = FALSE,
                              no_outline = TRUE),
                   
                   bsModal("modal_gt_13", "Data", "mgt13", size = "large",
                           DT::dataTableOutput("most_goal_team_table")
                   ) 
                   
                   
                   
                 )
                 
                 
                 
          )
          
        ) # End Fluid Row
        
        
        
        
        
)
  
)  
  