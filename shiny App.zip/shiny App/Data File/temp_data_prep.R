# Get Team Name
Team_names <- All_time_team_Stats[c(TRUE,rep(FALSE,5)),"Clubs"]

# repeat each team 6 times
Team_names <- rep(Team_names,each = 6)

# Set in Data
All_time_team_Stats$Club_Name <- Team_names

# Consistency Check
All_time_team_Stats[c(TRUE,rep(FALSE,5)),"Clubs"] == All_time_team_Stats[c(TRUE,rep(FALSE,5)),"Club_Name"]


# Relace in Clubs the team name with All time Record
Team_names <- unique(Team_names)

All_time_team_Stats$Clubs[All_time_team_Stats$Clubs %in% Team_names] <- "All Time Record"


