# Manager Stats Global ----

AllTimeManagersTable<- read_csv("Data File/Manager Data/AllTimeManagersTable.csv")

Most_Versatile_Clubs <- AllTimeManagersTable %>% 
  group_by(Club_Associated) %>% 
  summarise(
    Manager_count = n_distinct(Manager_Name)
    
  ) %>% 
  filter(
    Manager_count > 6
  )



AllTimeManagers_Nationalities <- read_csv("Data File/Manager Data/AllTimeManagers_Nationalities.csv")
