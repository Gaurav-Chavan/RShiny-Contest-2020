# Group Stage ----
All_TIme_Competition_Record_grp <- read_csv("Data File/Competition Stats/All_TIme_Competition_Record_grp.csv")

All_time_players_grps <<- read_csv("Data File/Competition Stats/All_time_players_grps.csv")

All_time_players_grps_1 <<- All_time_players_grps %>%
  group_by(Position) %>%   
  filter(Total > 10) %>%
  top_n(n = 5,wt = Total)  %>%
  arrange(Total) %>%
  mutate(Club = factor(Players, levels = .$Players)) %>%  
  select(Players,Position,Total)


names(All_time_players_grps_1) <- c("Player_Name","Position","Total_Appearance")




# Round 16 ----

All_TIme_Competition_Record_r16 <- read_csv("Data File/Competition Stats/All_TIme_Competition_Record_r16.csv")

All_time_players_r16 <<- read_csv("Data File/Competition Stats/All_time_players_r16.csv")

All_time_players_r16_1 <<- All_time_players_r16 %>%
  group_by(Position) %>%   
  filter(Total > 10) %>%
  top_n(n = 5,wt = Total)  %>%
  arrange(Total) %>%
  mutate(Club = factor(Players, levels = .$Players)) %>%  
  select(Players,Position,Total)


names(All_time_players_r16_1) <- c("Player_Name","Position","Total_Appearance")



# Quater Finals ----

All_time_Competition_Record_Quarter_finals <- read_csv("Data File/Competition Stats/All_time_Competition_Record_Quarter_finals.csv")

All_time_players_Quarter_final <<- read_csv("Data File/Competition Stats/All_time_players_Quarter_final.csv")

All_time_players_Quarter_final_1 <<- All_time_players_Quarter_final %>%
  group_by(Position) %>%   
  filter(Total > 10) %>%
  top_n(n = 5,wt = Total)  %>%
  arrange(Total) %>%
  mutate(Club = factor(Players, levels = .$Players)) %>%  
  select(Players,Position,Total)


names(All_time_players_Quarter_final_1) <- c("Player_Name","Position","Total_Appearance")


# Semi Finals ----

All_time_Competition_Record_Semi_finals <- read_csv("Data File/Competition Stats/All_time_Competition_Record_Semi_finals.csv")

All_time_players_Semi_final <<- read_csv("Data File/Competition Stats/All_time_players_Semi_final.csv")

All_time_players_Semi_final_1 <<- All_time_players_Semi_final %>%
  group_by(Position) %>%   
  filter(Total > 10) %>%
  top_n(n = 5,wt = Total)  %>%
  arrange(Total) %>%
  mutate(Club = factor(Players, levels = .$Players)) %>%  
  select(Players,Position,Total)


# Finals ----

All_TIme_Competition_Record_Finals <<- read_csv("Data File/Competition Stats/All TIme Competition Record Finals.csv")


All_time_players_final <<- read_csv("Data File/Competition Stats/All_time_players_final.csv")


All_time_players_final_1 <<- All_time_players_final %>%
  group_by(Position) %>%   
  filter(Total_Appearance > 2) %>%
  top_n(n = 5,wt = Total_Appearance)  %>%
  arrange(Total_Appearance) %>%
  mutate(Club = factor(Player_Name, levels = .$Player_Name)) %>%  
  select(Player_Name,Position,Total_Appearance)
